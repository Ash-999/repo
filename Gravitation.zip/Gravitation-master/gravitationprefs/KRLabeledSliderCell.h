#include <Preferences/PSSliderTableCell.h>

@interface KRLabeledSliderCell : PSSliderTableCell
@end